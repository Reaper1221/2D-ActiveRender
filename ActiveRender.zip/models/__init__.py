from . import *
# !D:\ActiveRender\ActiveRender\models\elipse - directory of this file
from . import elipse
# !D:\ActiveRender\ActiveRender\models\square - directory of this file
from . import square