import numpy as np

MINIMAL = -100000000000000000000000000000000000000000


class Objects:

    Screen_pointers = np.array([[MINIMAL,MINIMAL],[MINIMAL,MINIMAL]])
    Screen_pointers_ID_em = []
    Screen_pointers_id = [1]

    def __init__(self):
        self.Screen_pointers = np.array([[MINIMAL,MINIMAL],[MINIMAL,MINIMAL]]) # В данном масиве хранять все координаты точек на экране
        self.Screen_pointers_ID_em = [] # В этом масиве храниться количевстве точек пренадлежащуищие определённому объекту
        self.Screen_pointers_id = [1] # Этот массив хранит количевство точек до определённого объекта

    # Движение объекта по заданым координатам
    def moveObject(self, indexobject: int, x, y): 

        numberID = self.Screen_pointers_id[indexobject]

        for s in range(int(self.Screen_pointers_ID_em[indexobject])):
            s = s - 0

            self.Screen_pointers[numberID+s][0] = self.Screen_pointers[numberID+s][0] + x
            self.Screen_pointers[numberID+s][1] = self.Screen_pointers[numberID+s][1] + y

    # Ошибка не верного результата функции декоратора CreateObject
    def __DecoratorObjectError(self, func_name: str):
        print(f"ФАТАЛЬНАЯ ОШИБКА: ФУНКЦИЯ {func_name} = ВЕРНУЛА НЕ МАССИВ NUMPY!")
        print("ПРИМЕР ВЫВОДА: [[1, 1], [1, 2], [2, 1], [2, 2]]")
        print("ПЕРВАЯ ЦИФРА ЭТО X ВТОРАЯ ЭТО Y")
        exit()

    # Данный декоратор нужен для создания пользовательских объектов.
    def createObject(self, *args, **kargs):
        def func(func):
        
            def a(*args, **kargs):
         
                result = func(*args, **kargs)
         
                if type(result) != type(np.array([])):
                    self.__DecoratorObjectError(str(func.__name__))
                else:
                    for x in range(len(result)): 
                        if type(result[x-1]) != type(np.array([])): self.__DecoratorObjectError(str(func.__name__))
                    
                self.Screen_pointers = np.append(self.Screen_pointers, result, axis=0) # [0][0][0][0]
                self.Screen_pointers_ID_em.append(len(result))
                self.Screen_pointers_id.append(self.Screen_pointers_id[-1] + len(result))
                return result
            
            return a
        
        return func